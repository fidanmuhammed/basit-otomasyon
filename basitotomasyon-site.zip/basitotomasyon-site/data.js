/* =====================================================================
   SITE DATA — the only file you need to edit to update the site.
   Only add things that are real. Empty sections show an honest
   "coming soon" state, and Results stays hidden until you add numbers.

   Put your files in assets/examples/ and reference them with relative
   paths (no leading slash), e.g. "assets/examples/lamp-before.jpg".
   ===================================================================== */
window.SITE = {

  // Public contact email. Shows a "Get in touch" button. Leave "" to hide it.
  email: "",

  // Optional hero background video (short, muted, looping, ideally < 8 MB).
  // Example: "assets/hero.mp4". Leave "" to use the animated gradient.
  heroVideo: "",

  // Before/after examples. "before" = your original product photo,
  // "after" = the ad your automation generated (image or video).
  examples: [
    // {
    //   title: "Product name",
    //   note: "One line about the product or what the ad shows.",
    //   ratio: "1 / 1",                       // optional: "9 / 16", "4 / 5", "16 / 9"
    //   before: "assets/examples/lamp-before.jpg",
    //   after: { type: "video",               // "video" or "image"
    //            src: "assets/examples/lamp-ad.mp4",
    //            poster: "assets/examples/lamp-poster.jpg" },   // poster optional
    //   angles: [                             // optional: the other input photos
    //     "assets/examples/lamp-angle2.jpg",
    //     "assets/examples/lamp-angle3.jpg"
    //   ]
    // },
  ],

  // Real measured numbers only. Leave empty to hide the Results section.
  stats: [
    // { value: "2 min", label: "Average time per generated ad (measured over N runs)" },
  ],

  // Dated progress entries, newest first. Use real dates.
  log: [
    // { date: "2026-10-13", title: "Site published", text: "Project page is live." },
  ]
};
